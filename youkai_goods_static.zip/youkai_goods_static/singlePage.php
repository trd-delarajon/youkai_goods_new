<?php
require_once("config.php");

$smarty->display('single_page.tpl');
?>