<?php 

	require_once("config.php");

	//$smarty->display('category.tpl');

 ?>